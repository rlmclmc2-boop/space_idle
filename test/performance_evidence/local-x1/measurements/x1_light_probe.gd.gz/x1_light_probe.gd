extends SceneTree

class LiveScene extends "res://scripts/battlefield.gd":
 var label := "baseline"
 var rows: Array = []
 var events: Dictionary = {}
 var previous: Dictionary = {}
 var frame_started := 0
 var capture_started := 0
 var warmup_frames := 0
 func show_chrono_login_report() -> void:pass
 func show_qa_tools() -> void:pass
 func _notification(what: int) -> void:
  if what == NOTIFICATION_APPLICATION_FOCUS_OUT or what == NOTIFICATION_APPLICATION_FOCUS_IN:return
  super._notification(what)
 func _ready() -> void:
  super._ready()
  game.rng.seed=1701
  game.speed=1.0
  game.paused=false
  equipment_panel.set_upgrade_amount(1)
  equipment_tabs.current_tab=0
  for member in game.profile.crew:
   if game.crew.can_assign(game,str(member.crewId),"equipment_upgrade","equipment"):
    game.assign_crew(str(member.crewId),"equipment_upgrade","equipment")
    break
 func on_event(kind: String, info: Dictionary) -> void:
  super.on_event(kind,info)
  if capture_started>0:events[kind]=int(events.get(kind,0))+1
 func _process(delta: float) -> void:
  var now := Time.get_ticks_usec()
  if capture_started>0 and not previous.is_empty():
   previous.frame_us=now-frame_started
   previous.events=events.duplicate()
   rows.append(previous)
   if rows.size()>=3600:
    finish()
    return
  if capture_started==0:
   warmup_frames+=1
   if warmup_frames>=120:capture_started=now
  events.clear()
  frame_started=now
  var start := Time.get_ticks_usec()
  super._process(delta)
  if capture_started>0:
   previous={"elapsed_us":now-capture_started,"main_us":Time.get_ticks_usec()-start,"stage":game.stage,"state":int(game.state),"enemies":game.enemies.size(),"projectiles":game.projectiles.size(),"upgrade_level":int(game.profile.enhancementLevel)}
 func finish() -> void:
  var path := "res://.runtime/x1-light-"+label+".json"
  var report := {"rows":rows,"metadata":{"label":label,"window":DisplayServer.window_get_size(),"adapter":RenderingServer.get_video_adapter_name(),"renderer":RenderingServer.get_current_rendering_method(),"fps_cap":Engine.max_fps,"vsync":DisplayServer.window_get_vsync_mode(),"warmup_frames":120,"sample_frames":rows.size(),"game_sha256":FileAccess.get_sha256("res://scripts/game.gd"),"main_sha256":FileAccess.get_sha256("res://scripts/main.gd")}}
  var file := FileAccess.open(path,FileAccess.WRITE)
  file.store_string(JSON.stringify(report))
  file.close()
  print("LIGHT_SAMPLE ",ProjectSettings.globalize_path(path))
  get_tree().call_deferred("quit")

func _initialize() -> void:call_deferred("run")
func run() -> void:
 var label := "baseline"
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--x1-label="):label=arg.get_slice("=",1)
 var scene=load("res://main.tscn").instantiate()
 scene.set_script(LiveScene)
 scene.label=label
 root.add_child(scene)
 current_scene=scene
